CREATE DATABASE parkir;
USE parkir;

CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50),
    password VARCHAR(255),
    role ENUM('admin','petugas')
);

INSERT INTO users (username, password, role)
VALUES ('admin', MD5('admin123'), 'admin'),
       ('petugas', MD5('12345'), 'petugas');

CREATE TABLE kendaraan (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nomor_plat VARCHAR(20),
    jenis ENUM('roda2', 'roda4'),
    waktu_masuk DATETIME,
    waktu_keluar DATETIME NULL,
    tarif INT,
    total_bayar INT NULL
);

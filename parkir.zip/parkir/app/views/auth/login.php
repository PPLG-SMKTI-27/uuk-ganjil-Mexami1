<form method="post" action="/parkir/public/index.php?page=auth&action=login">
    <h2>Login Sistem Parkir</h2>
    <input type="text" name="username" placeholder="Username" required><br>
    <input type="password" name="password" placeholder="Password" required><br>
    <button type="submit">Login</button>
</form>

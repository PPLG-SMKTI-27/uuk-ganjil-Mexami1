<h2>Kendaraan Masuk</h2>

<form method="post" action="../../public/index.php?page=kendaraan&action=store">
    <label>Nomor Plat:</label><br>
    <input type="text" name="plat" required><br>

    <label>Jenis Kendaraan:</label><br>
    <select name="jenis">
        <option value="roda2">Roda 2</option>
        <option value="roda4">Roda 4</option>
    </select><br><br>

    <button type="submit">Simpan</button>
</form>

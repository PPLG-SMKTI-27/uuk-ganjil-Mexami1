<h2>Data Kendaraan Parkir</h2>

<a href="../../public/index.php?page=kendaraan&action=create">+ Kendaraan Masuk</a>
<a href="../../public/index.php?page=auth&action=logout" style="float:right">Logout</a>

<table border="1" cellpadding="8" cellspacing="0">
    <tr>
        <th>Plat</th>
        <th>Jenis</th>
        <th>Masuk</th>
        <th>Keluar</th>
        <th>Total</th>
        <th>Aksi</th>
    </tr>

    <?php while ($row = $data->fetch_assoc()): ?>
    <tr>
        <td><?= $row['nomor_plat'] ?></td>
        <td><?= $row['jenis'] ?></td>
        <td><?= $row['waktu_masuk'] ?></td>
        <td><?= $row['waktu_keluar'] ?></td>
        <td><?= $row['total_bayar'] ?></td>
        <td>
            <?php if (!$row['waktu_keluar']): ?>
                <a href="../../public/index.php?page=kendaraan&action=keluar&id=<?= $row['id'] ?>">KELUAR</a>
            <?php endif; ?>
            |
            <a href="../../public/index.php?page=kendaraan&action=delete&id=<?= $row['id'] ?>" 
               onclick="return confirm('Hapus data?')">Hapus</a>
        </td>
    </tr>
    <?php endwhile; ?>
</table>

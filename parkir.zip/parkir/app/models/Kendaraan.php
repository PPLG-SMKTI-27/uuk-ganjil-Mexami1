<?php
require_once 'Database.php';

class Kendaraan extends Database {

    public function getAll() {
        return $this->conn->query("SELECT * FROM kendaraan ORDER BY id DESC");
    }

    public function getById($id) {
        return $this->conn->query("SELECT * FROM kendaraan WHERE id=$id")->fetch_assoc();
    }

    public function create($plat, $jenis) {
        $tarif = ($jenis == 'roda2') ? 5000 : 10000;
        $stmt = $this->conn->prepare("INSERT INTO kendaraan (nomor_plat, jenis, waktu_masuk, tarif) VALUES (?, ?, NOW(), ?)");
        $stmt->bind_param("ssi", $plat, $jenis, $tarif);
        return $stmt->execute();
    }

    public function updateKeluar($id) {
        $stmt = $this->conn->prepare("
            UPDATE kendaraan 
            SET 
                waktu_keluar = NOW(),
                total_bayar = TIMESTAMPDIFF(HOUR, waktu_masuk, NOW()) * tarif
            WHERE id = ?
        ");
        $stmt->bind_param("i", $id);
        return $stmt->execute();
    }

    public function delete($id) {
        return $this->conn->query("DELETE FROM kendaraan WHERE id=$id");
    }
}

<?php
class Database {
    private $host = "localhost";
    private $db   = "parkir";
    private $user = "root";
    private $pass = "";
    protected $conn;

    public function __construct() {
        $this->conn = new mysqli($this->host, $this->user, $this->pass, $this->db);
        if ($this->conn->connect_error) {
            die("Error: " . $this->conn->connect_error);
        }
    }
}

<?php
require_once 'Database.php';

class User extends Database {

    public function login($username, $password) {
        $password = md5($password);
        $result = $this->conn->query("
            SELECT * FROM users 
            WHERE username='$username' AND password='$password'
        ");
        return $result->fetch_assoc();
    }
}

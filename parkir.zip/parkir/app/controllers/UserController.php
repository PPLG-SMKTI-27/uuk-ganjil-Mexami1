<?php
require_once '../models/User.php';

class UserController {

    public function login() {
        $user = new User();
        $data = $user->login($_POST['username'], $_POST['password']);

        if ($data) {
            session_start();
            $_SESSION['user'] = $data;
            header("Location: ../public/index.php?page=kendaraan");
        } else {
            echo "<script>alert('Login gagal'); window.location='../app/views/auth/login.php';</script>";
        }
    }

    public function logout() {
        session_start();
        session_destroy();
        header("Location: ../app/views/auth/login.php");
    }
}

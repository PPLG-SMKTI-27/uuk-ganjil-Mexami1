<?php
require_once '../models/Kendaraan.php';

class KendaraanController {

    private $model;

    public function __construct() {
        $this->model = new Kendaraan();
    }

    public function index() {
        $data = $this->model->getAll();
        include '../app/views/kendaraan/index.php';
    }

    public function create() {
        include '../app/views/kendaraan/create.php';
    }

    public function store() {
        $this->model->create($_POST['plat'], $_POST['jenis']);
        header("Location: ../public/index.php?page=kendaraan");
    }

    public function keluar($id) {
        $this->model->updateKeluar($id);
        header("Location: ../public/index.php?page=kendaraan");
    }

    public function delete($id) {
        $this->model->delete($id);
        header("Location: ../public/index.php?page=kendaraan");
    }
}

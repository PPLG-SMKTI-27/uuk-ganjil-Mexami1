<?php
$page = $_GET['page'] ?? 'kendaraan';
$action = $_GET['action'] ?? null;
$id = $_GET['id'] ?? null;

require_once '../app/controllers/KendaraanController.php';
require_once '../app/controllers/UserController.php';

$kendaraan = new KendaraanController();
$user = new UserController();

switch ($page) {

    case 'login':
        include '../app/views/auth/login.php';
        break;

    case 'auth':
        if ($action == 'login') $user->login();
        if ($action == 'logout') $user->logout();
        break;

    case 'kendaraan':
        if ($action == 'create') $kendaraan->create();
        else if ($action == 'store') $kendaraan->store();
        else if ($action == 'keluar') $kendaraan->keluar($id);
        else if ($action == 'delete') $kendaraan->delete($id);
        else $kendaraan->index();
        break;

    default:
        echo "404 Not Found";
}
        
<?php
session_start();

require "../config/database.php";
$db = Database::connect();

$url = isset($_GET['url']) ? explode("/", $_GET['url']) : [];

$controller = $url[0] ?? 'parking';
$method     = $url[1] ?? 'index';
$id         = $url[2] ?? null;

switch ($controller) {

    case 'parking':
        require "../app/controllers/ParkingController.php";
        $ctrl = new ParkingController($db);

        if ($method == 'index') $ctrl->index();
        if ($method == 'create') $ctrl->create();
        if ($method == 'store') $ctrl->store();
        if ($method == 'keluar') $ctrl->keluar($id);
    break;

    case 'login':
        require "../app/controllers/UserController.php";
        $ctrl = new UserController($db);

        if ($method == '') $ctrl->loginPage();
        if ($method == 'proses') $ctrl->login();
    break;

    default:
        echo "404 Not Found!";
}

CREATE DATABASE parking_db;
USE parking_db;

CREATE TABLE users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50),
    password VARCHAR(255),
    role ENUM('admin','petugas')
);

INSERT INTO users (username, password, role)
VALUES ('admin', '$2y$10$Qv6xCmNDKEmVs6jWRc67oORC5rzuol6h1SGVKXkar4FLKBJ3xFOou', 'admin');

CREATE TABLE parking (
    id INT PRIMARY KEY AUTO_INCREMENT,
    plat_nomor VARCHAR(20),
    jenis ENUM('motor','mobil'),
    waktu_masuk DATETIME,
    waktu_keluar DATETIME NULL,
    biaya INT NULL,
    status ENUM('parkir','keluar')
);

<?php

require_once "../app/models/User.php";

class UserController {

    private $user;

    public function __construct($db) {
        $this->user = new User($db);
    }

    public function loginPage() {
        include "../app/views/user/login.php";
    }

    public function login() {
        $username = $_POST['username'];
        $password = $_POST['password'];

        $result = $this->user->login($username, $password);

        if ($result) {
            session_start();
            $_SESSION['user'] = $result;
            header("Location: /parking");
        } else {
            echo "Login gagal!";
        }
    }
}

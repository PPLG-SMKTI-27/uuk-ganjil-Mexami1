<?php

require_once "../app/models/Parking.php";

class ParkingController {

    private $parking;

    public function __construct($db) {
        $this->parking = new Parking($db);
    }

    public function index() {
        $data = $this->parking->getAll();
        include "../app/views/parking/index.php";
    }

    public function create() {
        include "../app/views/parking/create.php";
    }

    public function store() {
        $this->parking->create($_POST['plat'], $_POST['jenis']);
        header("Location: /parking");
    }

    public function keluar($id) {
        $this->parking->keluar($id);
        header("Location: /parking");
    }
}

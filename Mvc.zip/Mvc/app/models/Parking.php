<?php

class Parking {

    private $db;

    public function __construct($db) {
        $this->db = $db;
    }

    public function create($plat, $jenis) {
        $sql = "INSERT INTO parking (plat_nomor, jenis, waktu_masuk, status)
                VALUES (?, ?, NOW(), 'parkir')";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([$plat, $jenis]);
    }

    public function getAll() {
        $stmt = $this->db->query("SELECT * FROM parking WHERE status='parkir'");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getById($id) {
        $stmt = $this->db->prepare("SELECT * FROM parking WHERE id=?");
        $stmt->execute([$id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function keluar($id) {
        $kendaraan = $this->getById($id);

        $biaya = ($kendaraan['jenis'] == 'motor') ? 5000 : 10000;

        $sql = "UPDATE parking 
                SET waktu_keluar = NOW(), biaya = ?, status='keluar' 
                WHERE id = ?";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([$biaya, $id]);
    }
}

<!DOCTYPE html>
<html>
<head>
    <title>Sistem Parkir</title>
    <style>
        body { font-family: Arial; margin: 20px; }
        a { padding: 6px; background: #3498db; color: white; text-decoration: none; }
    </style>
</head>
<body>
<h2>Sistem Parkir Pusat Perbelanjaan</h2>
<hr>

<?php include "../app/views/layouts/header.php"; ?>

<a href="/parking/create">+ Kendaraan Masuk</a>
<br><br>

<table border="1" cellpadding="10">
    <tr>
        <th>ID</th>
        <th>Plat</th>
        <th>Jenis</th>
        <th>Waktu Masuk</th>
        <th>Aksi</th>
    </tr>

    <?php foreach ($data as $row) : ?>
    <tr>
        <td><?= $row['id'] ?></td>
        <td><?= $row['plat_nomor'] ?></td>
        <td><?= $row['jenis'] ?></td>
        <td><?= $row['waktu_masuk'] ?></td>
        <td>
            <a href="/parking/keluar/<?= $row['id'] ?>">Keluarkan</a>
        </td>
    </tr>
    <?php endforeach; ?>

</table>

<?php include "../app/views/layouts/footer.php"; ?>

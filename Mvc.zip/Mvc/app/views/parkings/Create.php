<?php include "../app/views/layouts/header.php"; ?>

<h3>Input Kendaraan Masuk</h3>

<form method="POST" action="/parking/store">
    Plat Nomor: <input type="text" name="plat" required><br><br>

    Jenis Kendaraan:
    <select name="jenis">
        <option value="motor">Motor (Rp 5000)</option>
        <option value="mobil">Mobil (Rp 10000)</option>
    </select>
    <br><br>

    <button type="submit">Simpan</button>
</form>

<?php include "../app/views/layouts/footer.php"; ?>
